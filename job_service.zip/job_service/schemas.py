from pydantic import BaseModel
from typing import Optional

class JobCreate(BaseModel):
    title: str
    description: str
    skills: str
    experience: str
    education: str
    languages: Optional[str] = None
    contract_type: str
    salary: Optional[float] = None
    location: Optional[str] = None

class JobUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    skills: Optional[str] = None
    experience: Optional[str] = None
    education: Optional[str] = None
    languages: Optional[str] = None
    contract_type: Optional[str] = None
    salary: Optional[float] = None
    location: Optional[str] = None

class JobPreview(BaseModel):
    id: int
    title: str
    description: str
    skills: str
    experience: str
    education: str
    languages: Optional[str]
    contract_type: str
    salary: Optional[float]
    location: Optional[str]
    is_published: bool
